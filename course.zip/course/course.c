/**
 * @file course.c
 * @author ningy7@mcmaster.ca
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief add a student to the course allocate one memory space for that student
 * 
 * @param course a course of course type 
 * @param student a student of student type
 */
void enroll_student(Course *course, Student *student)
{
  /*
    add 1 student anyways
    move to next step depends on the current student number
    if there isn't any student use calloc, else use realloc
   */
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief print a course including it's name, code,
 * and total student and each student in this course
 * 
 * @param course a course of course type 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief input a course with output the top student in this course
 * 
 * @param course a course of course type 
 * @return Student* student of student type represent the top student
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
 //from the first student keep tracking of the max_average
// i index of students
  */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief analyze a course get the student who pass(>=50) this course into an array
 * 
 * @param course  a course of course type 
 * @param total_passing a pointer of the number of student who pass this course
 * @return Student* dynamic allocated array of student who passed this course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}