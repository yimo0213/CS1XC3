/**
 * @file course.h
 * @author ningy7@mcmaster.ca
 * @brief course library for managing courses, course type definition and function initializations
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief course type stores a course with name, code, 
 *        student array contain all students and number of students
 * 
 */
typedef struct _course 
{
  char name[100]; /**<the course title*/
  char code[10];  /**<the course code*/
  Student *students; /**<array contains all students in this course*/
  int total_students;/**<total students number*/
} Course;
/**
 * Course function declaration/initialization
 */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


