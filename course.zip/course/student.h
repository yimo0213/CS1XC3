/**
 * @file student.h
 * @author ningy7@mcmaster.ca
 * @brief student library for managing students, student type definition and function initializations
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief student type definition (struct + type def)
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**<the student first name*/
  char last_name[50];/**<the student last name*/
  char id[11]; /**<the student id*/
  double *grades; /**<the student's grade*/
  int num_grades; /**<the number of course that the student have with grade*/
} Student;

/**
 * @brief function initialization
 * 
 */
void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
